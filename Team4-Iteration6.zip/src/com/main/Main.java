package com.main;


public class Main {

	public static void main(String[] args) {
		
					
		Visualizer qua=new Visualizer();
		
		qua.initialize();
		
		
		
	}
}
